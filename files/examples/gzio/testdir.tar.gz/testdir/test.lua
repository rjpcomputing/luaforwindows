print"Hello, world!"
